<?php

$dia = "Sabado";
switch ($dia) { 

case 'Lunes':
    echo "Voy a ver Series";
    break;
    case "Martes":
        echo "Voy a jugar a ps4";
break;
case 'Miercoles':
    echo 'Jugare futbol en la deportiva';
    break;

    case 'Jueves':
        echo 'saldre a correr';
        break;

        case 'Viernes':
            echo 'saldre en bicicleta';
            break;
            case 'Sabado':
                echo 'Me comere una pizza';
                break;
                case 'domingo':
                    echo 'Saldre al cine';
                    break;

    default:
    echo "Voy a descanzar , no conozco a nadie";
}
echo "<br></br>";


$msj = "Mi nombre es Luis";

for($i= 0; $i <10; $i++){

    echo $msj . "" . "<br>";
}


echo "<br><br>";

$l = 0;
$cont = 0;

do{
    echo $l . "<br>";
    $cont +=$l;
    $l++;


}  while($l <=10);

echo "Valor total es :$cont";



?>