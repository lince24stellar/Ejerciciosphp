<?php

class Fruta {
    public $name;
    public $color;
    public $tamaño;
    public $sabor;

    public function showmethod() {

        echo "<p>Hola soy una fruta llamada: $this->name, color: $this->color, tamaño: $this->tamaño, sabor: $this->sabor </p>";
    }
}

$a = new Fruta();
$a->name = "Sandia";
$a->tamaño = "Grande";
$a->sabor = "Dulce";
$a->color = "Verde";

$a->showmethod();

 
$b = new Fruta();
$b->name = "Platano";    
$b->color = "Amarillo";
$b->tamaño = "Mediano";
$b->sabor = "dulce";

$b->showmethod();


$c = new Fruta();
$c->name = "Aguacate";
$c->color= "negro";
$c->tamaño = "pequeño";
$c->sabor = "neutral";

$c->showmethod();

$d = new Fruta();
$d->name = "Uvas";
$d->color = "violeta";
$d->tamaño ="pequeño";
$d->sabor = "dulce";

$d->showmethod();

$e = new Fruta();   
$e->name = "Naranjas";
$e->color = "Naranjas";
$e->tamaño = "Grandes";
$e->sabor = "Acido";

$e->showmethod();



?>


