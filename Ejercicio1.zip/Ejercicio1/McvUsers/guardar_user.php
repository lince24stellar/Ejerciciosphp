<?php
require_once 'modelos/users.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuario = $_POST['usuario'];
    $password = $_POST['password'];
    $email = $_POST['email'];

    $user = new Users($usuario, password_hash($password, PASSWORD_DEFAULT), $email);
    $user->guardar();

    echo "Usuario guardado correctamente.";
}
?>
