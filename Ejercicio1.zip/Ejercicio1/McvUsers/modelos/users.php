<?php
require_once("conexion.php");

class Users {
    private $id;
    private $usuario;
    private $password;
    private $email;

    const Tabla = 'Usuarios'; // Asegúrate de usar este nombre correctamente en las consultas

    public function getId() { 
        return $this->id;
    }

    public function getUsuario() {
        return $this->usuario;
    }

    public function getPassword() {
        return $this->password;
    }

    public function getEmail() { 
        return $this->email;
    }

    public function setUsuario($usuario) {
        $this->usuario = $usuario;
    }

    public function setPassword($password) {
        $this->password = $password;
    }

    public function setEmail($email) {
        $this->email = $email;
    }

    public function __construct($usuario, $password, $email, $id = null) {
        $this->usuario = $usuario;
        $this->password = $password;
        $this->email = $email;
        $this->id = $id;    
    }

    public function guardar() {
        $conexion = new conexion(); 

        if($this->id) {
            // Actualiza
            $consulta = $conexion->prepare('UPDATE ' . self::Tabla . ' SET usuario = :usuario, password = :password, email = :email WHERE id = :id');
            $consulta->bindParam(':usuario', $this->usuario);
            $consulta->bindParam(':password', $this->password);
            $consulta->bindParam(':email', $this->email);
            $consulta->bindParam(':id', $this->id);
            $consulta->execute();
        } else {
            // Inserta
            $consulta = $conexion->prepare('INSERT INTO ' . self::Tabla . ' (usuario, password, email) VALUES(:usuario, :password, :email)');
            $consulta->bindParam(':usuario', $this->usuario);
            $consulta->bindParam(':password', $this->password);
            $consulta->bindParam(':email', $this->email);
            $consulta->execute();
            $this->id = $conexion->lastInsertId();
        }

        $conexion = null;
    }
}
?>
