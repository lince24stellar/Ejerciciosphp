<?php


//Ejercicio 1 Crear un programa  que contenga las siguentes variables

//Variable que contenga tu nombre completo
$nombre="Luis Gerardo";
$apellidos ="Lopez lopez";
echo "Tu nombre completo es: <h2>$nombre $apellidos</h2>";
echo "<br><br>";

$edad=22;
echo "Tu edad es: <h2>$edad</h2>";
echo "<br><br>";

$hobbies = array("Ver Peliculas","Salir a correr","Jugar Videojuegos");
foreach($hobbies as $hobbies){
    echo "Mis hobbies faovritos son: <h2>$hobbies</h2>";

}
?>