<?php


$alumno1 = (object)["NombreCompleto" => "Victoria Rangel", "Matricula" => "281212", "Grupo" => "DSM203"];
$alumno2 = (object)["NombreCompleto" => "Vanessa Guerrero", "Matricula" => "8788658", "Grupo" => "DSM204"];
$alumno3 = (object)["NombreCompleto" => "Kevin Ramirez", "Matricula" => "66566464", "Grupo" => "DSM205"];
$alumno4 = (object)["NombreCompleto" => "Juan Jose", "Matricula" => "44477447", "Grupo" => "DSM206"];
$alumno5 = (object)["NombreCompleto" => "Nayelli Ponce", "Matricula" => "88668", "Grupo" => "DSM207"];

$alumnos = [$alumno1, $alumno2, $alumno3, $alumno4, $alumno5]; 

function mostrar($alumnos) {
    $totalAlumnos = count($alumnos); 
    for ($i = 0; $i < $totalAlumnos; $i++) {
        echo "<p>Hola! soy: " . $alumnos[$i]->NombreCompleto . ",<br> Matricula: " . $alumnos[$i]->Matricula . ", Grupo: " . $alumnos[$i]->Grupo . "</p>";
    }
}

mostrar($alumnos);


//


?>
